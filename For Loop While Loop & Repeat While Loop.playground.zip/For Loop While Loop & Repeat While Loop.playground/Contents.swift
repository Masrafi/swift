import UIKit
import Foundation


// 1. Introduction to For Loop

for i in 1 ..< 100 {
    print(i)
}

for j in 5 ... 95 {
    if j % 5 == 0 {
        print(j)
    }
}


// 2. Using value of "i" in a loop and the underscore variable


for i in 1 ... 12 {
    print("6 x \(i) = \(6*i)")
}


//Sometimes you dint need the value of the i in the code itself
for _ in 1 ... 20 {
    print("*****************")
}

var str = ""
for _ in 1 ... 10 {
    str += "I am awesome. "
}


// 3. Looping through arrays


var fruits = ["apple", "banana", "strawberry", "orange", "satsuma", "mango"]

for f in fruits {
    print("\(f)")
}

// if you need to get the index  of the array

for i in 0 ..< fruits.count {
    print("\(i+1) : \(fruits[i])")
}
 

// 4. Looping over dictionaries


let mesurements = ["bedroom" : 150, "kitchen": 120, "living" : 300, "bathroom" : 230]

for (room, length) in mesurements {
    print("\(room) curtain length is \(length)cm")
}

var teamScore = ["chelsea" : 108, "United" : 40, "City" : 42, "Arsenal" : 35, "Liverpool" : 21]

for(team, score) in teamScore {
    print("\(team) score is \(score)")
}



// 5. Problem and Solution: Maximum value in an array


// print the aximum number in a given array


var numbers5 = [2, 3, 4, 5, 6, 7, 22, 54, 9, 99,]
var max = numbers5[0]

for num in numbers5 {
    if max < num {
        max = num
    }
}
print(max)



// 6. Problem and Solution: Separate numbers into odd and even


//Separate the numbers in the folloeing array into two separate arrays, one array holding the odd and the other array holding the even numbers

var mixed = [2, 45, 9, 85, 5, 76, 45, 98, 7, 45, 32, 67, 6, 27, 32, 71]

var odd : [Int] = []
var even : [Int] = []

for number in mixed {
    
    if number % 2 == 0 {
        //even.appenrd(number)
        even += [number]
    } else {
        //odd.append(number)
        odd += [number]
    }
}
print(odd)
print(even)



// 7. Problem and Solution: Sum the content of an array


//You have been given an array of Integers, print the sum of all the numbers contained in the array
var numbers7 = [2, 45, 9, 85, 5, 76, 45, 98, 7, 45, 32, 67, 6, 27, 32, 71]
var sum = 0

for number in numbers7 {
    sum += number
    //sum = sum + number
}
print(sum )



// 8. Problem and Solution: Reversed array


// Create another array thet contain the reversed items in the given array
var numbers8 = [2, 45, 9, 85, 5, 76, 45, 98, 7, 45, 32, 67, 6, 27, 32, 71]

var reversed : [Int] = []

for i in 1 ... numbers8.count {
    reversed.append(numbers8[numbers8.count - i])
    //reversed += [numbers8[numbers8.count - i]]
    
    // OR
    
//    var index = numbers8.count - i
//    reversed.append(numbers8[index])
}
print(reversed)
print(numbers8.reversed())




// 9. Inner loops / Nested Loops


// Sometimes you want to run a for loop inside another loop
 var lines = ["Mum", "Dad", "Wife", "Kids", "Friends"]

var choruses = ["I love you", "I miss you", "I'll always be there for you"]

for line in lines {
    print("\n" + line)
    
    for chorus in choruses {
        print(chorus)
    }
}



// 10. Break statement


// Sometimes you want to stop a loop without reaching the end of the loop

var numbers10 = [2, 45, 9, 85, 5, 76, 45, 98, 7, 45, 32, 67, 6, 27, 32, 71]

numbers10.count

for number in numbers10 {
    
    if number == 7 {
        print("Number 7 found")
        break
    } else {
        print("\(number) : is not a 7")
    }
}


// 11. Continue statement



// Somethims you want to bypass some parts of your code in the loop
var numbers11 = [2, 99, 9, 85, 5, 76, 45, 71]

numbers11.count

for number in numbers11 {
    print("current number: \(number)")
    
    if number == 5 { // when number = 5, it stor and go back to the room and run again for next index
        continue
    }
    
    print("\t line after continue statement")
    
    if (number == 45) {
        break
    }
}
print("Break statement ended the loop")



// 12. Introduction to While Loop


var counter = 1

while counter <= 10 {
    print("Counter is \(counter)")
    counter += 1
}

var numbers12 = [2, 99, 9, 85, 5, 76, 45, 71]

var index12 = 0
let count12 = numbers12.count

while index12 < count12 {
    print(numbers12[index12])
    index12 += 1
}


// 13. Beware of an infinite loop


//An infinite loop happens when the condition that gets evaluated in your while loop is never false
//var counter13 = 0
//while counter13 < 10 {
//    print("Counter")
//}


// 14. Repeat while loop


var counter14 = 0

repeat {
    print("Counter is \(counter14)")
    counter14 += 1
} while counter14 < 10




// 15. Repeat while loop example


// wen want to generate two random numbers and make sure thay ar equal. When the randam number is equal the program is stop otherwise it continue
var count = 0
var random1 : Int
var random2 : Int

repeat {
    random1 = Int(arc4random_uniform(11)) //generate from 0 ... 10
    random2 = Int(arc4random_uniform(11))
    print("Random numbers: \(random1), \(random2)")
    count += 1
} while random1 != random2

print("Loo ran \(count) times")


// 16. Problem and Solution: Separate numbers to array - while loop


//separe the given number into array containing individual number e.g 13526 becomes [1, 3, 5, 2, 6

var number16 = 273291073

var array16 : [Int] = []

while number16 > 10 {
    var singleNumber = number16 % 10
    array16.append(singleNumber)
    
    number16 /= 10
}

array16.append(number16)
array16.reverse()
print(array16)


