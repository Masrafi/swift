import UIKit
import Foundation


// 1. Introduction to Dictionary

let mesurements = ["bedroom": 150, "kitchen": 120, "living": 300, "bathroom": 230]

let details = ["name": "dee odus", "month": "december", "location": "london"]


let mesurements2 = ["bedroom": 150, "kitchen": 120, "living": 300, "bathroom": 230]


// 2. Retrieving values from a dictionary


var measurement3 : [String : Int] = [:]

measurement3 = ["bedroom": 150, "kitchen": 120, "living": 300, "bathroom": 230]

measurement3["bedroom"]
measurement3["kitchen"]

print("Kitchen curtain mesurement is \(measurement3["living"]!)cm")


//3. Adding a new key-value pair to a dictionary

var userHeights: [String : Double] = [:]

userHeights["james"] = 185.5
userHeights["peter"] = 190
userHeights["lisa"] = 172
userHeights["bob"] = 150.3

userHeights


// 4. Updating value in a dictionary


userHeights.updateValue(180, forKey: "lisa")
userHeights.updateValue(186, forKey: "dee")

let height3 = userHeights.updateValue(180, forKey: "dee")
height3


// 5. Removing items from dictionary

var teamScores = ["Chelsea" : 38, "United" : 40, "City" : 42, "Arsenal" : 35, "Liverpool" : 21]

teamScores.removeValue(forKey: "Liverpool")

teamScores

teamScores["Arsenal"] = nil

teamScores


// 6. Other dictionary methods


let details6 = ["name": "dee odus", "month": "december", "location": "london"]

details6.count

var array = details6.keys

var dictKeys = Array(details6.keys)
dictKeys[0]

var dictValues = Array(details6.values)
dictValues[0]


