import UIKit
import Foundation


// 1. Introduction to Function


func showMessage() {
    print("Welcome to Florists")
}

showMessage()


// 2. Function parameters


func showMessage2(pageName: String) {
    print("Welcome to Florists. you are now on our \(pageName)")
}
showMessage2(pageName: "Home")
showMessage2(pageName: "About Us")
showMessage2(pageName: "Contact Us")


//second example
func playSong(lines: [String]) {
    
    var chorues = ["I love you", "I miss you", "I'll always be there for yoy"]
    
    for line in lines {
        print("\n\n" + line)
        for chorue in chorues {
            print(chorue)
        }
    }
}

var family = ["mum", "Dad", "wife", "kids", "Siblings"]
playSong(lines: family)

var friends = ["Natalis", "James", "Julie", "Bob", "Jay"]
playSong(lines: friends)

// 3. Multiple parameters of a function


func addThreeNumbers(first: Int, second: String, third: Double) {
    print("The three perameters are: \(first), \(second), \(third)")
}

addThreeNumbers(first: 55, second: "Masrafi Anam", third: 4.564)


// 4. Returning values from functions



func addThreeNumbers4(first: Int, second: Int, third: Int) ->Int {
    return first + second + third
}

let sum1 = addThreeNumbers4(first: 55, second: 34, third: 45)
print(sum1)

func movieRestrictionCheck (value: Int) -> String {
    var message = ""
    
    switch value {
    case 0 ... 3:
        message = "That's a baby"
    case 4 ... 11:
        message = "Young Kid"
    case 12 ... 18:
        message = "Teen and young"
    case 19 ... 90:
        message = "Permission granted"
    default:
        message = "Invalid"
    }
    return message
}

var result = movieRestrictionCheck(value: 66)
print(result)

// 5. Calling a function from another function



func splitNumber(number: Int) -> Int {
    var singleNumber = 0
    var array : [Int] = []
    
    var newNumber = number
    
    while newNumber > 10 {
        singleNumber = newNumber % 10
        array.append(singleNumber)
        
        newNumber /= 10
    }
    array.append(newNumber)
    
    let reversedNum = reverse1(numberArray: array)
    
    let sum5 = add(reversed: reversedNum)
    
    return sum5
}


func reverse1 (numberArray: [Int]) -> [Int] {
    return numberArray.reversed()
}

func add (reversed: [Int]) -> Int {
    var sum = 0
    for i in 0 ..< reversed.count {
        sum += reversed[i]
    }
    return sum
}


// 6. Parameter as a let constant

//The parameter of a function is a constant so you won't be able to change it

func reduceByOne (number: Int) -> Int {
    number = number - 1
    return number
}
