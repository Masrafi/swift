import UIKit

//1. Introduction
var greeting = "Hello, playground"
print(greeting)
3+2
print(3+2)
//single line of comment
/*multi
 line
 comment
 */

// 2. Constant and Variable

import Foundation

// let = const
let numberOfType = 4  // this value can't be change
//numberOfType = 5

var age = 16  // this value will be change
age = 20

// 3. Data Type

let myAge = 35   // Integer
let myName = "Masrafi"  // String
let temp = 87.5  // Floating
let isTaining = true   // Boolean


// 4. String Data Type
// type inference
var myName1 = "Masrafi"
print(myName1)
myName1 = "Anam"

// type annotation
let friend: String = "John"

// Type annotation missing
//let anotherFriend
//anotherFriend = "Peter"

let thirdFriend:String
thirdFriend = "Jac"

myName1.uppercased()
myName1.lowercased()
myName1.capitalized
myName1.isEmpty
myName1.hasPrefix("An")  //Check 1st two character
myName1.hasSuffix("am")  //Check last two character


// 5. Int Data Type

let x = 5
let y = 7

let z = x + y

let p : Int
p = 12

var q : Int = 16
q = 10


// 6. Float and Double Data Type

// Double is more accurate then Float
var x1 = 1.2
x1 = 2.3

var y1 : Float = 5
y1 = 5.6

var p1 : Double = 231234.123412342134
print(p1)

var q11 : Float = 86534.178341456



// 7. Boolean Data Tyupe


var isRaining2 : Bool = true
isRaining2 = false

// Cannot assign to value: 'isNight' is a 'let' constant
//let isNight = true
//isNight = false


// 8. String interpolation

let firstName = "Masrafi"
let lastName = "Anam"
let age1 = 35
let bodyTemp = 36.5

firstName + lastName

"My name is \(firstName) \(lastName), I am \(age) years old and my body temperature is \(bodyTemp)"
"If my body temperature is grater than \(bodyTemp * 2) then I am dead"

// Binary operator '+' cannot be applied to operands of type 'String' and 'Int'
// firstName + lastName + age



// 9. Good naming conventions to follow

var x4 = 5
var y4 = 6
var z4 = x4 + y4

var length = 3
var width = 4
var area = length - width

let name4 = "Red"
let name44 = "Ron"

let myName5 : String
//my friendName4
//
//initialAccountBalance  // right way
//
//initialaccountbalance
//
//initial_account_balance
//
//let nyName
