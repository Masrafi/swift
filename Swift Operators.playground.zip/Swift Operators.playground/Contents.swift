import UIKit
import Foundation

// 1. Arithmetic operators

//Addition +
//Subtraction -
// Division /
//Multilication *

let width = 5
let height = 6
let depth = 3

width + height
width - height
width / height
width * height

(width + height) * depth - width


// 2. Integer division and possible errors

let width2 : Double = 7
let height2 : Double = 2

width2 / height2


// 3 Remainder operator


let width3 : Double = 10
let height3 : Double = 6

width3.truncatingRemainder(dividingBy: height3)



// 4. Compound assignment operators


var x = 5

x = x + 1

x += 1

x -= 1

x /= 3

x *= 8


// 5. Comparison operator


let width4 = 4
let height4 =  7

width4 < height4
width4 <= height4
width4 > height4
width4 >= height4


// 6. Comparison operator - checking for equality


let width5 = 4
let height5 =  7

if (width5 == height5) {
    
}

let name = "Mas"
let friend = "An"
let friend1 = "An"

name == friend
name == name
friend == friend1


// 7. NOT operator


let width6 = 4
let height6 =  7

width6 < height6

!(width6 < height6)

let isRaining = true
!isRaining

width6 == height6
width6 != height6


// 8. How to find out the data types of variables


var str = "Mas Ana"
let width8 = 5
let height8 = 16.5
let isRaining8 = true

str.append(", that's my name")



// 9. Type Casting


var a = 10
var b : Double = Double(a)

var p = 10.45
var q = Int(p)
var r = Double(q)



// 10. Problem Solution 1 - Swap variables

// Ypu have two variable p = 10,q = 5, swap their values so that p = 5, and q = 10

var p2 = 10
var q2 = 5
var r2 : Int

r2 = p2
p2 = q2
q2 = r2
print(p2)
print(q2)


// 11. Problem Solution 2 - Area and perimeter

// calculate area of a circle given radius of 5
//Calculate the perimeter of a rectangle with sides 8 and 10 cm

var radius = 5.0
let pi = 3.1416
var areaOfCircle = pi * radius * radius
print("The area of circle is \(areaOfCircle)")

let length = 8
let width9 = 10
var areaOfRect = length * width9
var perimeter = 2 * (length + width9)
print("The area of the rectangle id \(areaOfRect)cm and the perimeter is \(perimeter)cm")



// 12. Problem Solution 3 - Calculate Percentage

//You were given 17 fruits; 3 bananas, 5 apples, 9 pears, calculate the percentage of each fruit

let bananas : Double = 3
let apples : Double = 5
let pears : Double = 9
let total : Double = 17

let bananaPerc = bananas / total * 100
let applesPerc = apples / total * 100
let pearsPerc = pears / total * 100


let totalPerc = bananaPerc + applesPerc + pearsPerc



// 13. Problem Solution 4 - Last digits of a number

// Print out the last digit of a number, e.g 1023 should print 3, 85 should print 5

let value = 1023
let remainder = 1023 % 10
let lastTwoDigit = 1023 % 100

let number = 1826738
let lastDigit = number % 10
let lastTwoDigit_ = number % 100
let lastthreeDigits = number % 1000
