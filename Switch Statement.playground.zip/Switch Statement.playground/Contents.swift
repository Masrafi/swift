import UIKit
import Foundation


// 1. Switch statements


let numberOfDrinks = 7

switch numberOfDrinks {
case 0:
    print("Zero")
case 1:
    print("One")
case 3:
    print("One")
case 4:
    print("One")
default:
    print("Not found")
}


// 2. Switch case - matching multiple values

let meal = "apple"

switch meal {
case "cereal", "onelette", "oat":
    print("You had breakfast")
case "rice", "lasagna":
    print("You had lunch")
case "banana", "orrange", "apple":
    print("Fruits")
default:
    print("Not found")
}


// 3. Switch range matching

let mark = 0

switch mark {
case 81 ... 100:
    print("Excellent")
case 66 ... 80:
    print("Merit")
case 41 ... 65:
    print("pass")
case 0 ..< 41:
    print("Fail")
default:
    print("Enter correct mark")
}



// 4. Switch break statement

let toneOfVoice = "quiet"

switch toneOfVoice {
case "shout":
    print("You shouted")
case "sarcasm":
    print("You werw sarcaastic")
case "quiet":
    print("Break here")
    break
    
default:
    print("you had other voice tone")
    
}



// 5. Fallthrough statement

let mark2 = 31

switch mark2 {
case 0 ... 20:
    print("You faild very badly")
    fallthrough
    
case 15 ... 30:
    print("failsd, but still did better than some")
    fallthrough
    
case 20 ... 40:
    print("could have studied more for a pass")
    
default:
    print("you passed")
}
