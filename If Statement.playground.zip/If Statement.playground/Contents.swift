import UIKit
import Foundation

// 1. Introduction to If statements

let itWillRain = true

if itWillRain {
    print("It will rain today")
}

let noOfCakes = 5
let noPfGuests = 7

if noOfCakes > noPfGuests {
    print("We have more cajes than guests")
}
if noOfCakes < noPfGuests {
    print("We have more cajes than guests")
}


// 2.  Else branch


let itWillRain2 = false

if itWillRain2 {
    print("It will rain today")
} else {
    print("It won't rain today")
}

let noOfCakes2 = 5
let noPfGuests2 = 7

if noOfCakes2 < noPfGuests2 {
    print("We have more cajes than guests")
} else {
    print("We have more cakes")
}



// 3. Nested if statement

let age = 21
let total = 29

if age > 20 {
    if total >= 30 {
        print("You are over 20")
    } else {
        print("You are older than 20")
    }
} else {
    print("You are not")
}



// 4. Else...if statements

let fruit = "banana"

if fruit == "apple" {
    print("Apple")
} else if fruit == "banana" {
    print("Banana")
} else if fruit == "pears" {
    print("Pears")
} else if fruit == "strawberry" {
    print("Strawberry")
} else {
    print("Other fruits")
}



// 5. Problem and Solution: Maximum of two numbers

let x = 10
let y = 12

if x > y {
    print("X is greater than Y")
} else if y > x {
    print("Y is greater than X")
} else {
    print("Nothing")
}



// 6. Problem and Solution: Even or odd number
// Giver a number you should determine if the number is even or odd

let number = 112233434

if number % 2 == 1 {
    print("\(number) is odd")
} else {
    print("\(number) is even")
}



// 7. Problem and Solution: Divisibilty calculations
// Check divisibilty of two numbers, is 1023 enenly divisible by 6? is 81 evenly divisible by 9?


let x2 = 1023
let y2 = 6

if x2 % y == 0 {
    print("\(x2) is evenly divisible by \(y2)")
} else {
    print("\(x2) is not evenly divisible by \(y2)")
}



// 8. Logical AND operator
//true && true = true
//true && false = false
//false && true = false
//false && false = false


let age1 = 20
let total1 = 30

if age1 >= 20 && total1 >= 30 {
    print("You can make this purcheses")
} else {
    print("Sorry")
}



// 9. Logical OR operator
//true || true = true
//true || false = true
//false || true = true
//false || false = false


let age2 = 20
let total2 = 30

if age2 >= 20 || total2 > 30 {
    print("You can make this purcheses")
} else {
    print("Sorry")
}



// 10. Problem Solution: Class marks
// Write a program that shows different messages to student based on the marks. A
//student that gets below 40 receives a "fail" message, a student that get over
//40 but at least 65 gets a "pass" message, a student that gets over 65 but under
//80 gets "merit" message and any student that scores 80 and above gets
//"distinction message.


let mark = 90

if mark >= 80 && mark > 100 {
    print("Excellent")
} else if mark < 80 && mark > 65 {
    print("merit")
} else if mark > 40 && mark <= 65 {
    print("pass")
} else {
    print("fail")
}



// 11. Problem Solution: Divisibility revisited
// check to seeif at least one number from 3, 6, 9 evenly divide 81

let number1 = 81

if number1 % 3 == 0 || number1 % 6 == 0 || number1 % 9 == 0 {
    print("\(number1) is evenly divisible by at least one number")
} else {
    print("\(number1) is not evenly divisble by any number")
}

// check if 105 is evenly divisble by all of 3, 5, 7

let number11 = 105

if number11 % 3 == 0 && number11 % 5 == 0 && number11 % 7 == 0 {
    print("\(number11) is evenly divisible by at least one number")
} else {
    print("\(number11) is not evenly divisble by any number")
}



// 12. Ternary conditional operator

let mark2 = 70
let passMark = 75
var message = ""

message = mark2 > passMark ? "You have pass, my frined" : "You failed"
print(message)
