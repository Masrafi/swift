import UIKit
import Foundation


// 1. Introduction to Optionals


// 2. Introduction to Optionals


// 3. Returning nil from a function


// 4. How to work with optional values



// 5. Unwrapping optional values


// 6. Force unwrap optional types

